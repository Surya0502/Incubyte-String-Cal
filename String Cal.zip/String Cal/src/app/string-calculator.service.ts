import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringCalculatorService {

  constructor() { }

  add(num: string): number {
    let total = 0;
    if (num === '') return 0;

    let delimiters = [',', '\n']; // default delimiters
    let numStr = num;

    if (num.startsWith('//')) {
      const delimiterEnd = num.indexOf('\n');
      const delimiterPart = num.substring(2, delimiterEnd);
      numStr = num.substring(delimiterEnd + 1);
      delimiters = [delimiterPart];
    }

    const delimitRegex = new RegExp(`[${delimiters.join('')}]`);
    const numsList = numStr.split(delimitRegex);

    const negativeNumbers: number[] = [];
    for (let i of numsList) {
      if (i !== '') {
        const number = Number(i);
        if (number < 0) negativeNumbers.push(number);
        else total = total + number;
      }
    }

    if (negativeNumbers?.length > 0) {
      throw new Error(`negative numbers not allowed ${negativeNumbers.join(',')}`);
    }

    return total;
  }
}
